# Distributed Chat Application
This is a combined backend + frontend project as defined.